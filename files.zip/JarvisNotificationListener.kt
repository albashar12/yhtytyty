package com.example.assistant

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Keeps the last 20 notifications so Jarvis can read them out. Enable in Settings > Notification access. */
class JarvisNotificationListener : NotificationListenerService() {
    companion object {
        private val recent = ArrayDeque<String>()
        fun snapshot(): String = synchronized(recent) {
            if (recent.isEmpty()) "No recent notifications (or notification access is not enabled)"
            else recent.joinToString("\n")
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val e = sbn.notification.extras
        val title = e.getCharSequence("android.title")?.toString().orEmpty()
        val text = e.getCharSequence("android.text")?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (ex: Exception) { sbn.packageName }
        synchronized(recent) {
            recent.addFirst("$app: $title - $text")
            while (recent.size > 20) recent.removeLast()
        }
    }
}
